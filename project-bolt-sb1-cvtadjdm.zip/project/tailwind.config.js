/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ivory: {
          50: '#FBF8F3',
          100: '#F5EFE4',
          200: '#EBE2D0',
        },
        cream: {
          50: '#FDFAF5',
          100: '#FAF4E9',
          200: '#F3E9D7',
          300: '#EBDBBE',
        },
        beige: {
          100: '#F5EDE0',
          200: '#EBDFCB',
          300: '#DFCDB0',
        },
        burgundy: {
          50: '#FBF1F0',
          100: '#F5DBD8',
          200: '#E8B0AC',
          300: '#D6857F',
          400: '#B85A53',
          500: '#933F39',
          600: '#6B2B26',
          700: '#4F1D19',
          800: '#371311',
          900: '#240B09',
        },
        chocolate: {
          300: '#5C4538',
          400: '#45342A',
          500: '#382A22',
          600: '#2A201A',
          700: '#1E1813',
        },
        gold: {
          100: '#F5EAC8',
          200: '#E9D49E',
          300: '#DCBE73',
          400: '#C9A24A',
          500: '#B08632',
          600: '#8C6A26',
          700: '#6A4F1C',
        },
      },
      fontFamily: {
        serif: ['Fraunces', 'Georgia', 'serif'],
        display: ['"Cormorant Garamond"', 'Georgia', 'serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
        urdu: ['"Cormorant Garamond"', 'Noto Nastaliq Urdu', 'serif'],
      },
      boxShadow: {
        book: '0 4px 16px -4px rgba(56, 42, 34, 0.18), 0 8px 32px -8px rgba(56, 42, 34, 0.12)',
        'book-hover': '0 12px 36px -8px rgba(56, 42, 34, 0.28), 0 20px 56px -16px rgba(56, 42, 34, 0.18)',
        soft: '0 2px 12px -2px rgba(56, 42, 34, 0.08)',
      },
      borderRadius: {
        book: '2px 6px 6px 2px',
      },
      keyframes: {
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'slide-down': {
          '0%': { opacity: '0', transform: 'translateY(-12px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'scale-in': {
          '0%': { opacity: '0', transform: 'scale(0.96)' },
          '100%': { opacity: '1', transform: 'scale(1)' },
        },
      },
      animation: {
        'fade-in': 'fade-in 0.5s ease-out',
        'fade-up': 'fade-up 0.6s ease-out both',
        'slide-down': 'slide-down 0.3s ease-out',
        'scale-in': 'scale-in 0.3s ease-out',
      },
    },
  },
  plugins: [],
};

import { Link } from 'react-router-dom';
import { Heart, ShoppingBag, Trash2, ArrowLeft } from 'lucide-react';
import { books, formatPKR } from '@/data';
import { BookCover } from '@/components/BookCover';
import { useStore } from '@/store/StoreContext';

export function WishlistPage() {
  const { wishlist, removeFromWishlist, addToCart } = useStore();
  const wishlistBooks = wishlist
    .map((id) => books.find((b) => b.id === id))
    .filter((b): b is NonNullable<typeof b> => b !== undefined);

  if (wishlistBooks.length === 0) {
    return (
      <div className="container-px mx-auto max-w-2xl py-20 text-center">
        <div className="inline-flex p-6 rounded-full bg-cream-100 mb-6">
          <Heart className="h-12 w-12 text-chocolate-300" />
        </div>
        <h1 className="section-title mb-3">Your wishlist is empty</h1>
        <p className="text-chocolate-400 mb-8">Save your favourite novels here to find them again later.</p>
        <Link to="/books" className="btn-primary">Discover Books</Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div className="container-px mx-auto max-w-7xl py-8">
        <Link to="/books" className="inline-flex items-center gap-2 text-sm text-chocolate-400 hover:text-burgundy-600 transition-colors mb-6">
          <ArrowLeft className="h-4 w-4" />
          Continue shopping
        </Link>

        <h1 className="section-title mb-2">Your Wishlist</h1>
        <p className="text-chocolate-400 mb-8">{wishlistBooks.length} {wishlistBooks.length === 1 ? 'book' : 'books'} saved</p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {wishlistBooks.map((book) => (
            <div key={book.id} className="card p-3 flex flex-col">
              <Link to={`/books/${book.id}`} className="block">
                <BookCover book={book} className="shadow-book hover:shadow-book-hover hover:scale-[1.03] transition-all duration-500" />
              </Link>
              <div className="flex flex-col flex-grow px-1 pt-3">
                <span className="text-[10px] uppercase tracking-wide text-gold-600 font-medium">{book.category}</span>
                <Link to={`/books/${book.id}`}>
                  <h3 className="font-serif text-base text-chocolate-600 hover:text-burgundy-600 transition-colors line-clamp-2 min-h-[2.5rem]">{book.title}</h3>
                </Link>
                <p className="text-xs text-chocolate-400 mb-2">by {book.author}</p>
                <p className="font-serif text-lg text-burgundy-600 font-semibold mb-3">{formatPKR(book.price)}</p>
                <div className="flex gap-2 mt-auto">
                  <button onClick={() => addToCart(book.id)} className="btn-primary flex-1 text-sm py-2.5">
                    <ShoppingBag className="h-4 w-4" />
                    Add to Cart
                  </button>
                  <button
                    onClick={() => removeFromWishlist(book.id)}
                    className="p-2.5 rounded-full border border-cream-200 text-chocolate-400 hover:text-burgundy-600 hover:border-burgundy-200 transition-colors"
                    aria-label="Remove from wishlist"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

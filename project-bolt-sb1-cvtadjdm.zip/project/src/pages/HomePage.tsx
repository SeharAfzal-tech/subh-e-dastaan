import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, Star, Sparkles } from 'lucide-react';
import { books, collections, heroImage, heroImageAlt, aboutImage } from '@/data';
import { BookCover } from '@/components/BookCover';
import { BookCarousel } from '@/components/BookCarousel';
import type { CollectionCard } from '@/types';

const collectionIcons: Record<string, React.ReactNode> = {
  'book-open': <BookOpen className="h-5 w-5" />,
  globe: <BookOpen className="h-5 w-5" />,
  heart: <BookOpen className="h-5 w-5" />,
  search: <BookOpen className="h-5 w-5" />,
  sparkles: <Sparkles className="h-5 w-5" />,
  mountain: <BookOpen className="h-5 w-5" />,
  star: <Star className="h-5 w-5" />,
  sunrise: <BookOpen className="h-5 w-5" />,
};

export function HomePage() {
  const featuredBooks = books.slice(0, 8);
  const newBooks = books.filter((b) => b.isNew);
  const urduPopular = books.filter((b) => b.language === 'urdu').slice(0, 8);
  const internationalFiction = books.filter((b) => b.language === 'english').slice(0, 8);
  const mustReadClassics = books.filter((b) => b.category === 'Must-Read Classics').concat(books.filter((b) => b.genre === 'Classic')).slice(0, 8);
  const mysteryBooks = books.filter((b) => b.genre.includes('Mystery') || b.genre.includes('Thriller')).slice(0, 8);
  const heroCovers = books.filter((b) => ['peer-e-kamil', 'the-alchemist', 'harry-potter-1', 'the-midnight-library', 'aab-e-hayat', 'a-thousand-splendid-suns'].includes(b.id));

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-cream-100 to-cream-50">
        <div className="absolute inset-0 opacity-20">
          <img
            src={heroImage}
            alt="Stack of vintage books in warm sunlight"
            className="h-full w-full object-cover"
          />
        </div>
        <div className="relative container-px mx-auto max-w-7xl py-16 lg:py-24">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="animate-fade-up">
              <p className="eyebrow mb-4">Welcome to Subh-e-Dastaan</p>
              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl text-chocolate-600 leading-tight text-balance mb-6">
                Every Story Begins with a Little Magic.
              </h1>
              <p className="text-lg text-chocolate-400 leading-relaxed max-w-lg mb-8 text-balance">
                Discover the worlds hidden between the pages. From unforgettable Urdu novels to international literary masterpieces, find the stories your heart has been searching for.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link to="/books" className="btn-primary">
                  Explore All Books
                  <ArrowRight className="h-4 w-4" />
                </Link>
                <Link to="/books?category=Readers%27+Favourites" className="btn-outline">
                  Discover Bestsellers
                </Link>
              </div>
            </div>

            {/* Hero cover collage */}
            <div className="relative hidden lg:flex justify-center items-center">
              <div className="grid grid-cols-3 gap-3 lg:gap-4 max-w-md">
                {heroCovers.slice(0, 6).map((book, i) => (
                  <Link
                    to={`/books/${book.id}`}
                    key={book.id}
                    className={`transition-all duration-500 hover:scale-105 hover:z-10 ${i % 2 === 0 ? 'translate-y-4' : '-translate-y-4'}`}
                  >
                    <BookCover book={book} className="shadow-book-hover" />
                  </Link>
                ))}
              </div>
              <div className="absolute -z-10 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 h-[420px] w-[420px] rounded-full bg-gold-200/30 blur-3xl" />
            </div>
          </div>
        </div>
      </section>

      {/* Featured Collections */}
      <section className="py-16 lg:py-20 bg-cream-50">
        <div className="container-px mx-auto max-w-7xl">
          <div className="text-center mb-12">
            <p className="eyebrow mb-2">Curated for every reader</p>
            <h2 className="section-title">Featured Collections</h2>
            <p className="text-chocolate-400 mt-3 max-w-xl mx-auto">
              Explore handpicked selections from our shelves, each offering a distinct doorway into the world of stories.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {collections.map((col: CollectionCard) => (
              <CollectionCardItem key={col.id} collection={col} />
            ))}
          </div>
        </div>
      </section>

      {/* Carousels */}
      <BookCarousel books={featuredBooks} title="Popular Urdu Novels" eyebrow="Urdu Literature" />
      <BookCarousel books={internationalFiction} title="International Fiction" eyebrow="English Novels" />

      {/* Quote Banner */}
      <section className="py-16 bg-burgundy-700 relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <img src={heroImageAlt} alt="" className="h-full w-full object-cover" />
        </div>
        <div className="relative container-px mx-auto max-w-3xl text-center">
          <Sparkles className="h-8 w-8 text-gold-300 mx-auto mb-4" />
          <p className="font-display text-2xl sm:text-3xl text-cream-50 italic leading-relaxed text-balance">
            "A reader lives a thousand lives before they die. The one who never reads lives only one."
          </p>
          <p className="text-gold-300 mt-4 text-sm tracking-wide">— George R. R. Martin</p>
        </div>
      </section>

      <BookCarousel books={newBooks} title="New Arrivals" eyebrow="Fresh on our shelves" />
      <BookCarousel books={mustReadClassics} title="Must-Read Classics" eyebrow="Timeless literature" />
      <BookCarousel books={mysteryBooks} title="Mystery and Suspense" eyebrow="Page-turners" />

      {/* About teaser */}
      <section className="py-16 lg:py-20 bg-cream-100">
        <div className="container-px mx-auto max-w-7xl">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="relative rounded-2xl overflow-hidden shadow-book">
              <img
                src={aboutImage}
                alt="Bookstore shelves filled with vintage books"
                className="w-full h-[400px] object-cover"
              />
            </div>
            <div>
              <p className="eyebrow mb-3">Our Story</p>
              <h2 className="section-title mb-5">A peaceful library at sunrise</h2>
              <p className="text-chocolate-400 leading-relaxed mb-4">
                Welcome to Subh-e-Dastaan, a home for readers who believe every book holds a world of its own. From the emotional depth of Urdu literature to the imaginative worlds of international fiction, our goal is to help readers discover stories worth remembering.
              </p>
              <p className="text-chocolate-400 leading-relaxed mb-6">
                Based in Khanpur, Sindh, Pakistan, we bring together a growing collection of novels for readers of different ages, interests, and literary tastes.
              </p>
              <Link to="/about" className="btn-outline">
                Read More About Us
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function CollectionCardItem({ collection }: { collection: CollectionCard }) {
  const linkTarget = collection.filterNew
    ? '/books?new=true'
    : collection.filterLanguage
      ? `/books?lang=${collection.filterLanguage}`
      : collection.filterGenre
        ? `/books?genre=${encodeURIComponent(collection.filterGenre)}`
        : collection.filterCategory
          ? `/books?category=${encodeURIComponent(collection.filterCategory)}`
          : '/books';

  return (
    <Link to={linkTarget} className="group relative rounded-2xl overflow-hidden shadow-book hover:shadow-book-hover transition-all duration-500">
      <div className="aspect-[3/4] overflow-hidden">
        <img
          src={collection.imageUrl}
          alt={collection.title}
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-chocolate-600/90 via-chocolate-600/40 to-transparent" />
      <div className="absolute inset-x-0 bottom-0 p-5 text-cream-50">
        <div className="flex items-center gap-2 mb-2">
          <div className="p-1.5 rounded-full bg-gold-400/90 text-chocolate-600">
            {collectionIcons[collection.icon]}
          </div>
        </div>
        <h3 className="font-serif text-lg leading-snug mb-1">{collection.title}</h3>
        <p className="text-xs text-cream-100/80 leading-relaxed line-clamp-2 mb-3">{collection.description}</p>
        <span className="inline-flex items-center gap-1.5 text-xs font-medium text-gold-300 group-hover:text-gold-200 transition-colors">
          Explore Collection
          <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
        </span>
      </div>
    </Link>
  );
}

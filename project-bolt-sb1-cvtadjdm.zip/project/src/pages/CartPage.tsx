import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Minus, Plus, Trash2, ShoppingBag, ArrowLeft, CheckCircle2 } from 'lucide-react';
import { books, formatPKR } from '@/data';
import { BookCover } from '@/components/BookCover';
import { useStore } from '@/store/StoreContext';
import type { CheckoutForm } from '@/types';

export function CartPage() {
  const { cart, updateQuantity, removeFromCart, cartSubtotal, clearCart, showToast } = useStore();
  const [showCheckout, setShowCheckout] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState<CheckoutForm>({
    fullName: '',
    phone: '',
    email: '',
    city: '',
    address: '',
    notes: '',
  });

  const cartBooks = cart.map((item) => ({
    ...item,
    book: books.find((b) => b.id === item.bookId)!,
  })).filter((item) => item.book);

  const shipping = cartSubtotal > 3000 ? 0 : 200;
  const total = cartSubtotal + shipping;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    clearCart();
    showToast('Demo order placed successfully');
  };

  if (submitted) {
    return (
      <div className="container-px mx-auto max-w-2xl py-20 text-center">
        <div className="inline-flex p-6 rounded-full bg-gold-100 mb-6">
          <CheckCircle2 className="h-12 w-12 text-gold-600" />
        </div>
        <h1 className="section-title mb-3">Demo Order Placed</h1>
        <p className="text-chocolate-400 mb-2">Thank you, {form.fullName}!</p>
        <p className="text-chocolate-400 mb-8 max-w-md mx-auto">
          This is a demo checkout — no real order has been placed and no payment has been processed. The cart has been cleared for this demonstration.
        </p>
        <div className="flex justify-center gap-4">
          <Link to="/books" className="btn-primary">Continue Shopping</Link>
          <Link to="/" className="btn-outline">Back to Home</Link>
        </div>
      </div>
    );
  }

  if (cartBooks.length === 0) {
    return (
      <div className="container-px mx-auto max-w-2xl py-20 text-center">
        <div className="inline-flex p-6 rounded-full bg-cream-100 mb-6">
          <ShoppingBag className="h-12 w-12 text-chocolate-300" />
        </div>
        <h1 className="section-title mb-3">Your cart is empty</h1>
        <p className="text-chocolate-400 mb-8">Browse our collection and add your favourite stories to the cart.</p>
        <Link to="/books" className="btn-primary">Explore All Books</Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <div className="container-px mx-auto max-w-7xl py-8">
        <Link to="/books" className="inline-flex items-center gap-2 text-sm text-chocolate-400 hover:text-burgundy-600 transition-colors mb-6">
          <ArrowLeft className="h-4 w-4" />
          Continue shopping
        </Link>

        <h1 className="section-title mb-8">Shopping Cart</h1>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart items */}
          <div className="lg:col-span-2 space-y-4">
            {cartBooks.map((item) => (
              <div key={item.bookId} className="card p-4 flex gap-4">
                <Link to={`/books/${item.book.id}`} className="flex-shrink-0 w-20">
                  <BookCover book={item.book} className="shadow-book" />
                </Link>
                <div className="flex-grow flex flex-col">
                  <div className="flex justify-between gap-4">
                    <div>
                      <span className="text-[10px] uppercase tracking-wide text-gold-600 font-medium">{item.book.category}</span>
                      <Link to={`/books/${item.book.id}`}>
                        <h3 className="font-serif text-base text-chocolate-600 hover:text-burgundy-600 transition-colors">{item.book.title}</h3>
                      </Link>
                      <p className="text-xs text-chocolate-400">by {item.book.author}</p>
                    </div>
                    <p className="font-serif text-lg text-burgundy-600 font-semibold">
                      {formatPKR(item.book.price * item.quantity)}
                    </p>
                  </div>
                  <div className="flex items-center justify-between mt-auto pt-3">
                    <div className="flex items-center border border-cream-200 rounded-full">
                      <button
                        onClick={() => updateQuantity(item.bookId, item.quantity - 1)}
                        className="p-2 text-chocolate-400 hover:text-burgundy-600 transition-colors"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="h-3.5 w-3.5" />
                      </button>
                      <span className="w-8 text-center text-sm font-medium text-chocolate-500">{item.quantity}</span>
                      <button
                        onClick={() => updateQuantity(item.bookId, item.quantity + 1)}
                        className="p-2 text-chocolate-400 hover:text-burgundy-600 transition-colors"
                        aria-label="Increase quantity"
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <button
                      onClick={() => removeFromCart(item.bookId)}
                      className="text-chocolate-300 hover:text-burgundy-600 transition-colors"
                      aria-label="Remove from cart"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
            <button
              onClick={clearCart}
              className="text-sm text-chocolate-400 hover:text-burgundy-600 transition-colors"
            >
              Clear entire cart
            </button>
          </div>

          {/* Summary */}
          <div className="lg:col-span-1">
            <div className="card p-6 sticky top-28">
              <h3 className="font-serif text-lg text-chocolate-600 mb-4">Order Summary</h3>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between text-chocolate-400">
                  <span>Subtotal ({cart.length} items)</span>
                  <span className="font-medium text-chocolate-500">{formatPKR(cartSubtotal)}</span>
                </div>
                <div className="flex justify-between text-chocolate-400">
                  <span>Shipping</span>
                  <span className="font-medium text-chocolate-500">{shipping === 0 ? 'Free' : formatPKR(shipping)}</span>
                </div>
                {shipping === 0 && cartSubtotal > 0 && (
                  <p className="text-xs text-gold-600">Free shipping on orders over PKR 3,000</p>
                )}
                <div className="pt-3 border-t border-cream-200 flex justify-between items-baseline">
                  <span className="font-serif text-lg text-chocolate-600">Total</span>
                  <span className="font-serif text-2xl text-burgundy-600 font-bold">{formatPKR(total)}</span>
                </div>
              </div>

              {!showCheckout ? (
                <button onClick={() => setShowCheckout(true)} className="btn-primary w-full mt-6">
                  Proceed to Checkout
                </button>
              ) : (
                <form onSubmit={handleSubmit} className="mt-6 space-y-3">
                  <div className="bg-gold-100 border border-gold-200 rounded-xl p-3 mb-2">
                    <p className="text-xs text-gold-700 font-medium">Demo Checkout</p>
                    <p className="text-xs text-chocolate-400 mt-1">No payment will be processed. This is for demonstration only.</p>
                  </div>
                  <input
                    type="text"
                    required
                    value={form.fullName}
                    onChange={(e) => setForm({ ...form, fullName: e.target.value })}
                    placeholder="Full name *"
                    className="input-field text-sm"
                  />
                  <input
                    type="tel"
                    required
                    value={form.phone}
                    onChange={(e) => setForm({ ...form, phone: e.target.value })}
                    placeholder="Phone number *"
                    className="input-field text-sm"
                  />
                  <input
                    type="email"
                    value={form.email}
                    onChange={(e) => setForm({ ...form, email: e.target.value })}
                    placeholder="Email (optional)"
                    className="input-field text-sm"
                  />
                  <input
                    type="text"
                    required
                    value={form.city}
                    onChange={(e) => setForm({ ...form, city: e.target.value })}
                    placeholder="City *"
                    className="input-field text-sm"
                  />
                  <textarea
                    required
                    value={form.address}
                    onChange={(e) => setForm({ ...form, address: e.target.value })}
                    placeholder="Complete delivery address *"
                    rows={3}
                    className="input-field text-sm"
                  />
                  <textarea
                    value={form.notes}
                    onChange={(e) => setForm({ ...form, notes: e.target.value })}
                    placeholder="Order notes (optional)"
                    rows={2}
                    className="input-field text-sm"
                  />
                  <button type="submit" className="btn-primary w-full">
                    Place Demo Order
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

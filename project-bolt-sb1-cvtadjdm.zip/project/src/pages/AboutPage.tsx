import { Link } from 'react-router-dom';
import { ArrowRight, BookOpen, Heart, MapPin } from 'lucide-react';
import { aboutImage } from '@/data';

export function AboutPage() {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-b from-cream-100 to-cream-50 py-16">
        <div className="absolute inset-0 opacity-15">
          <img src={aboutImage} alt="" className="h-full w-full object-cover" />
        </div>
        <div className="relative container-px mx-auto max-w-3xl text-center">
          <p className="eyebrow mb-3">Our Story</p>
          <h1 className="font-serif text-4xl sm:text-5xl text-chocolate-600 mb-4">About Subh-e-Dastaan</h1>
          <p className="text-lg font-display italic text-burgundy-600">Every dawn brings a new story</p>
        </div>
      </section>

      {/* Content */}
      <section className="py-16">
        <div className="container-px mx-auto max-w-3xl">
          <div className="prose-content space-y-6 text-lg text-chocolate-400 leading-relaxed">
            <p>
              Welcome to <span className="font-serif text-chocolate-600 font-medium">Subh-e-Dastaan</span>, a home for readers who believe every book holds a world of its own. From the emotional depth of Urdu literature to the imaginative worlds of international fiction, our goal is to help readers discover stories worth remembering.
            </p>
            <p>
              Based in Khanpur, Sindh, Pakistan, Subh-e-Dastaan brings together a growing collection of novels for readers of different ages, interests, and literary tastes.
            </p>
            <p className="font-serif text-xl text-chocolate-600 italic text-center py-6 border-y border-cream-200">
              At Subh-e-Dastaan, every dawn brings a new story, and every reader deserves a place in the world of books.
            </p>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-16 bg-cream-100">
        <div className="container-px mx-auto max-w-7xl">
          <h2 className="section-title text-center mb-12">What We Believe</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <ValueCard
              icon={<BookOpen className="h-7 w-7" />}
              title="Stories Worth Remembering"
              description="We curate every title with care, selecting novels that move, challenge, and stay with you long after the last page."
            />
            <ValueCard
              icon={<Heart className="h-7 w-7" />}
              title="For Every Reader"
              description="From timeless Urdu classics to the latest international bestsellers, our shelves welcome readers of every taste and language."
            />
            <ValueCard
              icon={<MapPin className="h-7 w-7" />}
              title="Rooted in Khanpur"
              description="Proudly based in Khanpur, Sindh, we serve book lovers across Pakistan with a passion for literature and community."
            />
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 text-center">
        <div className="container-px mx-auto max-w-2xl">
          <h2 className="section-title mb-4">Begin Your Next Story</h2>
          <p className="text-chocolate-400 mb-8">Explore our collection of Urdu and English novels and find the book that's been waiting for you.</p>
          <Link to="/books" className="btn-primary">
            Browse All Books
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </div>
  );
}

function ValueCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="text-center">
      <div className="inline-flex p-4 rounded-full bg-gold-100 text-burgundy-600 mb-4">{icon}</div>
      <h3 className="font-serif text-xl text-chocolate-600 mb-3">{title}</h3>
      <p className="text-chocolate-400 leading-relaxed">{description}</p>
    </div>
  );
}

import { Link } from 'react-router-dom';
import { Shield, FileText, Truck } from 'lucide-react';

type InfoPageProps = {
  type: 'privacy' | 'terms' | 'shipping';
};

const pageContent = {
  privacy: {
    icon: <Shield className="h-10 w-10" />,
    title: 'Privacy Policy',
    intro: 'Subh-e-Dastaan respects your privacy. This policy explains how we handle your information.',
    sections: [
      { h: 'Information We Collect', p: 'When you place an order or contact us, we may collect your name, phone number, email, and delivery address. We do not store payment details.' },
      { h: 'How We Use Information', p: 'Your information is used solely to process orders, respond to inquiries, and improve our service. We never sell or share your data with third parties for marketing.' },
      { h: 'Data Storage', p: 'This is a demo website. When a backend is connected, customer data will be stored securely in compliance with applicable Pakistani regulations.' },
      { h: 'Cookies & Local Storage', p: 'We use browser local storage to remember your cart and wishlist between visits. No tracking cookies are used.' },
    ],
  },
  terms: {
    icon: <FileText className="h-10 w-10" />,
    title: 'Terms & Conditions',
    intro: 'These terms govern your use of the Subh-e-Dastaan website.',
    sections: [
      { h: 'Demo Notice', p: 'This website is currently a demo. Orders placed here are not real and no payment is processed. Prices are illustrative sample prices, not verified supplier prices.' },
      { h: 'Product Information', p: 'We strive for accuracy in book titles, authors, and descriptions. Page counts and publishers are shown only when verified. Cover images are designed representations.' },
      { h: 'Pricing', p: 'All prices are shown in Pakistani Rupees (PKR) and are subject to change. Discounted prices reflect sample offers and may differ from actual retail pricing.' },
      { h: 'Limitation of Liability', p: 'Subh-e-Dastaan is not liable for any indirect damages arising from the use of this website. Our liability is limited to the value of the order in question.' },
    ],
  },
  shipping: {
    icon: <Truck className="h-10 w-10" />,
    title: 'Shipping & Returns',
    intro: 'Information about delivery and returns for Subh-e-Dastaan orders.',
    sections: [
      { h: 'Delivery Areas', p: 'We aim to deliver across Pakistan. Specific delivery zones and timelines will be confirmed when our logistics system is fully operational.' },
      { h: 'Shipping Costs', p: 'In this demo, shipping is calculated at PKR 200, with free shipping on orders over PKR 3,000. Actual rates will be set when the store goes live.' },
      { h: 'Returns', p: 'Books may be returned within 7 days of delivery if they arrive damaged or incorrect. Please contact us with your order details for a replacement or refund.' },
      { h: 'Demo Notice', p: 'Since no real orders are processed on this demo site, these policies are informational and will take effect when the store begins live operations.' },
    ],
  },
};

export function InfoPage({ type }: InfoPageProps) {
  const content = pageContent[type];

  return (
    <div className="min-h-screen">
      <section className="bg-cream-100 py-12">
        <div className="container-px mx-auto max-w-3xl text-center">
          <div className="inline-flex p-4 rounded-full bg-gold-100 text-burgundy-600 mb-4">{content.icon}</div>
          <h1 className="section-title">{content.title}</h1>
          <p className="text-chocolate-400 mt-3">{content.intro}</p>
        </div>
      </section>

      <section className="py-16">
        <div className="container-px mx-auto max-w-3xl">
          <div className="space-y-8">
            {content.sections.map((section, i) => (
              <div key={i}>
                <h2 className="font-serif text-xl text-chocolate-600 mb-2">{section.h}</h2>
                <p className="text-chocolate-400 leading-relaxed">{section.p}</p>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <Link to="/contact" className="btn-outline">Questions? Contact Us</Link>
          </div>
        </div>
      </section>
    </div>
  );
}

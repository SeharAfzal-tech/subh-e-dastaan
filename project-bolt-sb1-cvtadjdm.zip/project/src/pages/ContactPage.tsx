import { useState } from 'react';
import { MapPin, Mail, CheckCircle2, Send } from 'lucide-react';

export function ContactPage() {
  const [submitted, setSubmitted] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="min-h-screen">
      {/* Header */}
      <section className="bg-cream-100 py-12">
        <div className="container-px mx-auto max-w-7xl text-center">
          <p className="eyebrow mb-3">Get in Touch</p>
          <h1 className="section-title">Contact Us</h1>
          <p className="text-chocolate-400 mt-3 max-w-lg mx-auto">
            Have a question about a book or your order? We'd love to hear from you.
          </p>
        </div>
      </section>

      <section className="py-16">
        <div className="container-px mx-auto max-w-5xl">
          <div className="grid md:grid-cols-5 gap-8">
            {/* Contact info */}
            <div className="md:col-span-2 space-y-6">
              <div>
                <h3 className="font-serif text-lg text-chocolate-600 mb-4">Reach Us</h3>
                <div className="space-y-4">
                  <ContactItem icon={<MapPin className="h-5 w-5" />} label="Location" value="Khanpur, Sindh, Pakistan" />
                  <ContactItem icon={<Mail className="h-5 w-5" />} label="Email" value="hello@subh-e-dastaan.com" />
                </div>
              </div>
              <div className="rounded-2xl bg-cream-100 p-5 border border-cream-200">
                <p className="text-xs text-gold-600 font-semibold uppercase tracking-wide mb-1">Note</p>
                <p className="text-sm text-chocolate-400 leading-relaxed">
                  This contact form is a demo. No message will actually be sent until a backend or email service is configured.
                </p>
              </div>
            </div>

            {/* Form */}
            <div className="md:col-span-3">
              {submitted ? (
                <div className="card p-8 text-center">
                  <div className="inline-flex p-5 rounded-full bg-gold-100 mb-4">
                    <CheckCircle2 className="h-10 w-10 text-gold-600" />
                  </div>
                  <h3 className="font-serif text-xl text-chocolate-600 mb-2">Demo Message Submitted</h3>
                  <p className="text-chocolate-400 mb-6">
                    Thank you, {form.name}! This is a demo form — no message was actually delivered. When a backend is connected, your message will be sent to our team.
                  </p>
                  <button
                    onClick={() => {
                      setSubmitted(false);
                      setForm({ name: '', email: '', subject: '', message: '' });
                    }}
                    className="btn-outline"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="card p-6 space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-chocolate-500 mb-1">Name *</label>
                    <input
                      type="text"
                      required
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className="input-field"
                      placeholder="Your name"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-chocolate-500 mb-1">Email *</label>
                    <input
                      type="email"
                      required
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className="input-field"
                      placeholder="you@example.com"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-chocolate-500 mb-1">Subject *</label>
                    <input
                      type="text"
                      required
                      value={form.subject}
                      onChange={(e) => setForm({ ...form, subject: e.target.value })}
                      className="input-field"
                      placeholder="How can we help?"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-chocolate-500 mb-1">Message *</label>
                    <textarea
                      required
                      rows={5}
                      value={form.message}
                      onChange={(e) => setForm({ ...form, message: e.target.value })}
                      className="input-field"
                      placeholder="Write your message here..."
                    />
                  </div>
                  <button type="submit" className="btn-primary w-full">
                    <Send className="h-4 w-4" />
                    Send Demo Message
                  </button>
                </form>
              )}
            </div>
          </div>

          {/* Location */}
          <div className="mt-12">
            <h3 className="font-serif text-lg text-chocolate-600 mb-4 text-center">Our Location</h3>
            <div className="card overflow-hidden">
              <div className="relative h-64 bg-cream-100 flex items-center justify-center">
                <div className="text-center">
                  <div className="inline-flex p-4 rounded-full bg-burgundy-600 text-cream-50 mb-3 animate-fade-in">
                    <MapPin className="h-8 w-8" />
                  </div>
                  <p className="font-serif text-lg text-chocolate-600">Khanpur, Sindh, Pakistan</p>
                  <p className="text-sm text-chocolate-400 mt-1">Exact storefront coordinates will appear here when available.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

function ContactItem({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="p-2.5 rounded-full bg-gold-100 text-burgundy-600 flex-shrink-0">{icon}</div>
      <div>
        <p className="text-xs text-chocolate-300 uppercase tracking-wide">{label}</p>
        <p className="text-chocolate-500 font-medium">{value}</p>
      </div>
    </div>
  );
}

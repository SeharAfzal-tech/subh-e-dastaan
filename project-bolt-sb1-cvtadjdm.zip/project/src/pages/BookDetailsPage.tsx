import { useState } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, ShoppingBag, Heart, Minus, Plus, CheckCircle2, BookOpen, Globe, Tag } from 'lucide-react';
import { getBookById, getRelatedBooks, formatPKR } from '@/data';
import { BookCover } from '@/components/BookCover';
import { BookCard } from '@/components/BookCard';
import { useStore } from '@/store/StoreContext';

export function BookDetailsPage() {
  const { id } = useParams<{ id: string }>();
  const book = id ? getBookById(id) : undefined;
  const navigate = useNavigate();
  const { addToCart, toggleWishlist, isInWishlist } = useStore();
  const [quantity, setQuantity] = useState(1);

  if (!book) {
    return (
      <div className="container-px mx-auto max-w-3xl py-20 text-center">
        <h1 className="section-title mb-4">Book not found</h1>
        <p className="text-chocolate-400 mb-6">We couldn't find the book you're looking for.</p>
        <Link to="/books" className="btn-primary">Back to All Books</Link>
      </div>
    );
  }

  const related = getRelatedBooks(book);
  const wished = isInWishlist(book.id);
  const discount = book.originalPrice ? Math.round(((book.originalPrice - book.price) / book.originalPrice) * 100) : 0;

  return (
    <div className="min-h-screen">
      <div className="container-px mx-auto max-w-7xl py-8">
        <button
          onClick={() => navigate(-1)}
          className="inline-flex items-center gap-2 text-sm text-chocolate-400 hover:text-burgundy-600 transition-colors mb-8"
        >
          <ArrowLeft className="h-4 w-4" />
          Back to Books
        </button>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Cover */}
          <div className="flex justify-center lg:justify-start">
            <div className="relative w-full max-w-sm">
              <div className="absolute -inset-4 bg-gold-200/20 rounded-3xl blur-2xl" />
              <div className="relative">
                <BookCover book={book} className="shadow-book-hover" />
              </div>
              <div className="absolute top-4 left-4 flex flex-col gap-1.5">
                {book.isNew && (
                  <span className="bg-gold-400 text-chocolate-600 text-xs font-bold uppercase tracking-wide px-3 py-1 rounded-full">
                    New
                  </span>
                )}
                {discount > 0 && (
                  <span className="bg-burgundy-600 text-cream-50 text-xs font-bold px-3 py-1 rounded-full">
                    -{discount}% OFF
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Details */}
          <div>
            <span className="inline-block text-xs uppercase tracking-wide text-gold-600 font-semibold mb-2">
              {book.category}
            </span>
            <h1 className="font-serif text-3xl lg:text-4xl text-chocolate-600 leading-tight mb-2">
              {book.title}
            </h1>
            {book.titleUrdu && (
              <p className="font-urdu text-2xl text-burgundy-600 mb-3" dir="rtl">{book.titleUrdu}</p>
            )}
            <p className="text-lg text-chocolate-400 mb-6">by {book.author}</p>

            {/* Meta badges */}
            <div className="flex flex-wrap gap-3 mb-6">
              <Badge icon={<BookOpen className="h-3.5 w-3.5" />}>
                Language: {book.language === 'urdu' ? 'Urdu' : 'English'}
              </Badge>
              <Badge icon={<Tag className="h-3.5 w-3.5" />}>
                Genre: {book.genre}
              </Badge>
            </div>

            {/* Price */}
            <div className="flex items-baseline gap-3 mb-2">
              <span className="font-serif text-3xl text-burgundy-600 font-bold">{formatPKR(book.price)}</span>
              {book.originalPrice && (
                <span className="text-lg text-chocolate-300 line-through">{formatPKR(book.originalPrice)}</span>
              )}
              {discount > 0 && (
                <span className="text-sm text-gold-600 font-medium">Save {discount}%</span>
              )}
            </div>

            <p className="text-sm text-chocolate-400 mb-6 flex items-center gap-2">
              <CheckCircle2 className="h-4 w-4 text-gold-500" />
              In stock (demo data)
            </p>

            {/* Description */}
            <div className="mb-8">
              <h3 className="font-serif text-lg text-chocolate-600 mb-2">Description</h3>
              <p className="text-chocolate-400 leading-relaxed">{book.description}</p>
            </div>

            {/* Verified details */}
            <div className="grid grid-cols-2 gap-4 mb-8 text-sm">
              <div>
                <p className="text-chocolate-300 text-xs uppercase tracking-wide">Pages</p>
                <p className="text-chocolate-500 font-medium">{book.pages ?? 'Not verified'}</p>
              </div>
              <div>
                <p className="text-chocolate-300 text-xs uppercase tracking-wide">Publisher</p>
                <p className="text-chocolate-500 font-medium">{book.publisher ?? 'Not verified'}</p>
              </div>
            </div>

            {/* Quantity & Actions */}
            <div className="flex items-center gap-4 mb-4">
              <div className="flex items-center border border-cream-200 rounded-full bg-white">
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="p-3 text-chocolate-400 hover:text-burgundy-600 transition-colors"
                  aria-label="Decrease quantity"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="w-10 text-center font-medium text-chocolate-500">{quantity}</span>
                <button
                  onClick={() => setQuantity((q) => q + 1)}
                  className="p-3 text-chocolate-400 hover:text-burgundy-600 transition-colors"
                  aria-label="Increase quantity"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
              <button
                onClick={() => addToCart(book.id, quantity)}
                className="btn-primary flex-grow"
              >
                <ShoppingBag className="h-4 w-4" />
                Add to Cart
              </button>
              <button
                onClick={() => toggleWishlist(book.id)}
                className={`p-3 rounded-full border transition-all ${
                  wished ? 'bg-burgundy-50 border-burgundy-200 text-burgundy-600' : 'border-cream-200 text-chocolate-400 hover:border-gold-300 hover:text-burgundy-600'
                }`}
                aria-label="Add to wishlist"
              >
                <Heart className={`h-5 w-5 ${wished ? 'fill-burgundy-600' : ''}`} />
              </button>
            </div>
          </div>
        </div>

        {/* Related */}
        {related.length > 0 && (
          <section className="mt-20">
            <h2 className="section-title mb-8">Related Novels</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
              {related.map((b) => (
                <BookCard key={b.id} book={b} />
              ))}
            </div>
          </section>
        )}
      </div>
    </div>
  );
}

function Badge({ icon, children }: { icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-cream-100 text-chocolate-500 text-xs font-medium">
      {icon}
      {children}
    </span>
  );
}

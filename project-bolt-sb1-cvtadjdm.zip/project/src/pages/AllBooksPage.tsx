import { useMemo, useState, useEffect } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Search, SlidersHorizontal, X } from 'lucide-react';
import { books, getAuthors, getGenres, getCategories } from '@/data';
import type { Language } from '@/types';
import { BookCard } from '@/components/BookCard';

type SortOption = 'featured' | 'price-low' | 'price-high' | 'alpha' | 'newest';

export function AllBooksPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [query, setQuery] = useState(searchParams.get('q') || '');
  const [language, setLanguage] = useState<string>(searchParams.get('lang') || '');
  const [author, setAuthor] = useState(searchParams.get('author') || '');
  const [genre, setGenre] = useState(searchParams.get('genre') || '');
  const [category, setCategory] = useState(searchParams.get('category') || '');
  const [newOnly, setNewOnly] = useState(searchParams.get('new') === 'true');
  const [minPrice, setMinPrice] = useState('');
  const [maxPrice, setMaxPrice] = useState('');
  const [sort, setSort] = useState<SortOption>('featured');
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    setQuery(searchParams.get('q') || '');
    setLanguage(searchParams.get('lang') || '');
    setAuthor(searchParams.get('author') || '');
    setGenre(searchParams.get('genre') || '');
    setCategory(searchParams.get('category') || '');
    setNewOnly(searchParams.get('new') === 'true');
  }, [searchParams]);

  const authors = useMemo(() => getAuthors(), []);
  const genres = useMemo(() => getGenres(), []);
  const categories = useMemo(() => getCategories(), []);

  const filtered = useMemo(() => {
    let result = [...books];
    const q = query.toLowerCase().trim();

    if (q) {
      result = result.filter(
        (b) =>
          b.title.toLowerCase().includes(q) ||
          b.author.toLowerCase().includes(q) ||
          b.language.toLowerCase().includes(q) ||
          b.genre.toLowerCase().includes(q) ||
          b.category.toLowerCase().includes(q) ||
          (b.titleUrdu?.includes(q) ?? false),
      );
    }

    if (language) result = result.filter((b) => b.language === language);
    if (author) result = result.filter((b) => b.author === author);
    if (genre) result = result.filter((b) => b.genre === genre);
    if (category) result = result.filter((b) => b.category === category);
    if (newOnly) result = result.filter((b) => b.isNew);

    const min = minPrice ? parseInt(minPrice) : 0;
    const max = maxPrice ? parseInt(maxPrice) : Infinity;
    result = result.filter((b) => b.price >= min && b.price <= max);

    switch (sort) {
      case 'price-low':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'alpha':
        result.sort((a, b) => a.title.localeCompare(b.title));
        break;
      case 'newest':
        result.sort((a, b) => b.dateAdded.localeCompare(a.dateAdded));
        break;
      default:
        break;
    }

    return result;
  }, [query, language, author, genre, category, newOnly, minPrice, maxPrice, sort]);

  const clearFilters = () => {
    setQuery('');
    setLanguage('');
    setAuthor('');
    setGenre('');
    setCategory('');
    setNewOnly(false);
    setMinPrice('');
    setMaxPrice('');
    setSearchParams({});
  };

  const hasFilters = query || language || author || genre || category || newOnly || minPrice || maxPrice;

  return (
    <div className="min-h-screen">
      {/* Page header */}
      <div className="bg-cream-100 py-12">
        <div className="container-px mx-auto max-w-7xl">
          <h1 className="section-title text-center">All Books</h1>
          <p className="text-chocolate-400 text-center mt-3 max-w-lg mx-auto">
            Browse our complete collection of {books.length} Urdu and English novels.
          </p>
        </div>
      </div>

      <div className="container-px mx-auto max-w-7xl py-10">
        {/* Search & Sort Bar */}
        <div className="flex flex-col sm:flex-row gap-4 mb-8">
          <div className="relative flex-grow">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-chocolate-300" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by title, author, language, or category..."
              className="w-full rounded-xl border border-cream-200 bg-white py-3 pl-12 pr-4 text-chocolate-500 placeholder:text-chocolate-300/50 focus:border-gold-400 focus:ring-2 focus:ring-gold-200/50 focus:outline-none"
            />
          </div>
          <button
            onClick={() => setShowFilters((v) => !v)}
            className="btn-outline sm:hidden"
          >
            <SlidersHorizontal className="h-4 w-4" />
            Filters
          </button>
          <select
            value={sort}
            onChange={(e) => setSort(e.target.value as SortOption)}
            className="rounded-xl border border-cream-200 bg-white px-4 py-3 text-chocolate-500 focus:border-gold-400 focus:ring-2 focus:ring-gold-200/50 focus:outline-none"
          >
            <option value="featured">Featured</option>
            <option value="price-low">Price: Low to High</option>
            <option value="price-high">Price: High to Low</option>
            <option value="alpha">Alphabetical</option>
            <option value="newest">Newest First</option>
          </select>
        </div>

        <div className="flex gap-8">
          {/* Filters Sidebar */}
          <aside className={`${showFilters ? 'block' : 'hidden'} lg:block w-full lg:w-64 flex-shrink-0`}>
            <div className="card p-5 sticky top-28">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-serif text-lg text-chocolate-600">Filters</h3>
                {hasFilters && (
                  <button onClick={clearFilters} className="text-xs text-burgundy-600 hover:underline flex items-center gap-1">
                    <X className="h-3 w-3" />
                    Clear all
                  </button>
                )}
              </div>

              <FilterGroup label="Language">
                <select value={language} onChange={(e) => setLanguage(e.target.value)} className="input-field text-sm">
                  <option value="">All languages</option>
                  <option value="urdu">Urdu</option>
                  <option value="english">English</option>
                </select>
              </FilterGroup>

              <FilterGroup label="Author">
                <select value={author} onChange={(e) => setAuthor(e.target.value)} className="input-field text-sm">
                  <option value="">All authors</option>
                  {authors.map((a) => (
                    <option key={a} value={a}>{a}</option>
                  ))}
                </select>
              </FilterGroup>

              <FilterGroup label="Genre">
                <select value={genre} onChange={(e) => setGenre(e.target.value)} className="input-field text-sm">
                  <option value="">All genres</option>
                  {genres.map((g) => (
                    <option key={g} value={g}>{g}</option>
                  ))}
                </select>
              </FilterGroup>

              <FilterGroup label="Category">
                <select value={category} onChange={(e) => setCategory(e.target.value)} className="input-field text-sm">
                  <option value="">All categories</option>
                  {categories.map((c) => (
                    <option key={c} value={c}>{c}</option>
                  ))}
                </select>
              </FilterGroup>

              <FilterGroup label="Price Range (PKR)">
                <div className="flex items-center gap-2">
                  <input type="number" value={minPrice} onChange={(e) => setMinPrice(e.target.value)} placeholder="Min" className="input-field text-sm" />
                  <span className="text-chocolate-300">–</span>
                  <input type="number" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} placeholder="Max" className="input-field text-sm" />
                </div>
              </FilterGroup>

              <FilterGroup label="Availability">
                <label className="flex items-center gap-2 text-sm text-chocolate-500 cursor-pointer">
                  <input type="checkbox" checked={newOnly} onChange={(e) => setNewOnly(e.target.checked)} className="accent-burgundy-600" />
                  New Arrivals only
                </label>
              </FilterGroup>
            </div>
          </aside>

          {/* Book Grid */}
          <div className="flex-grow">
            <p className="text-sm text-chocolate-400 mb-4">
              Showing {filtered.length} {filtered.length === 1 ? 'book' : 'books'}
            </p>
            {filtered.length === 0 ? (
              <div className="text-center py-20">
                <div className="inline-flex p-4 rounded-full bg-cream-100 mb-4">
                  <Search className="h-8 w-8 text-chocolate-300" />
                </div>
                <h3 className="font-serif text-xl text-chocolate-500 mb-2">No books found</h3>
                <p className="text-chocolate-400 mb-4">Try adjusting your search or filters.</p>
                <button onClick={clearFilters} className="btn-outline">Clear all filters</button>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                {filtered.map((book) => (
                  <BookCard key={book.id} book={book} />
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function FilterGroup({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="mb-4 pb-4 border-b border-cream-100 last:border-0">
      <p className="text-xs font-semibold uppercase tracking-wide text-chocolate-400 mb-2">{label}</p>
      {children}
    </div>
  );
}

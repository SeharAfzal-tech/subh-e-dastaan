import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import type { CartItem } from '@/types';
import { books, getBookById } from '@/data';

type StoreContextValue = {
  cart: CartItem[];
  wishlist: string[];
  addToCart: (bookId: string, quantity?: number) => void;
  removeFromCart: (bookId: string) => void;
  updateQuantity: (bookId: string, quantity: number) => void;
  clearCart: () => void;
  cartCount: number;
  cartSubtotal: number;
  isInWishlist: (bookId: string) => boolean;
  toggleWishlist: (bookId: string) => void;
  removeFromWishlist: (bookId: string) => void;
  showToast: (message: string) => void;
  toast: string | null;
};

const StoreContext = createContext<StoreContextValue | null>(null);

const CART_KEY = 'subh-e-dastaan-cart';
const WISHLIST_KEY = 'subh-e-dastaan-wishlist';

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(CART_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [wishlist, setWishlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(WISHLIST_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem(WISHLIST_KEY, JSON.stringify(wishlist));
  }, [wishlist]);

  const showToast = useCallback((message: string) => {
    setToast(message);
    window.setTimeout(() => setToast(null), 2500);
  }, []);

  const addToCart = useCallback(
    (bookId: string, quantity = 1) => {
      setCart((prev) => {
        const existing = prev.find((item) => item.bookId === bookId);
        if (existing) {
          return prev.map((item) => (item.bookId === bookId ? { ...item, quantity: item.quantity + quantity } : item));
        }
        return [...prev, { bookId, quantity }];
      });
      const book = getBookById(bookId);
      showToast(`"${book?.title}" added to cart`);
    },
    [showToast],
  );

  const removeFromCart = useCallback((bookId: string) => {
    setCart((prev) => prev.filter((item) => item.bookId !== bookId));
  }, []);

  const updateQuantity = useCallback((bookId: string, quantity: number) => {
    if (quantity < 1) return;
    setCart((prev) => prev.map((item) => (item.bookId === bookId ? { ...item, quantity } : item)));
  }, []);

  const clearCart = useCallback(() => setCart([]), []);

  const isInWishlist = useCallback((bookId: string) => wishlist.includes(bookId), [wishlist]);

  const toggleWishlist = useCallback(
    (bookId: string) => {
      setWishlist((prev) => {
        if (prev.includes(bookId)) {
          showToast('Removed from wishlist');
          return prev.filter((id) => id !== bookId);
        }
        const book = getBookById(bookId);
        showToast(`"${book?.title}" added to wishlist`);
        return [...prev, bookId];
      });
    },
    [showToast],
  );

  const removeFromWishlist = useCallback((bookId: string) => {
    setWishlist((prev) => prev.filter((id) => id !== bookId));
  }, []);

  const cartCount = useMemo(() => cart.reduce((sum, item) => sum + item.quantity, 0), [cart]);

  const cartSubtotal = useMemo(
    () =>
      cart.reduce((sum, item) => {
        const book = books.find((b) => b.id === item.bookId);
        return sum + (book ? book.price * item.quantity : 0);
      }, 0),
    [cart],
  );

  const value: StoreContextValue = {
    cart,
    wishlist,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    cartCount,
    cartSubtotal,
    isInWishlist,
    toggleWishlist,
    removeFromWishlist,
    showToast,
    toast,
  };

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used within StoreProvider');
  return ctx;
}

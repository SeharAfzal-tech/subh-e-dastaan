import { BrowserRouter, Routes, Route, useLocation } from 'react-router-dom';
import { useEffect } from 'react';
import { StoreProvider } from '@/store/StoreContext';
import { Layout } from '@/components/Layout';
import { AnnouncementBar, Navbar } from '@/components/Navbar';
import { Footer } from '@/components/Footer';
import { HomePage } from '@/pages/HomePage';
import { AllBooksPage } from '@/pages/AllBooksPage';
import { BookDetailsPage } from '@/pages/BookDetailsPage';
import { CartPage } from '@/pages/CartPage';
import { WishlistPage } from '@/pages/WishlistPage';
import { AboutPage } from '@/pages/AboutPage';
import { ContactPage } from '@/pages/ContactPage';
import { InfoPage } from '@/pages/InfoPage';

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

function NotFoundPage() {
  return (
    <div className="container-px mx-auto max-w-2xl py-20 text-center">
      <p className="font-serif text-6xl text-burgundy-600 mb-4">404</p>
      <h1 className="section-title mb-3">Page Not Found</h1>
      <p className="text-chocolate-400 mb-8">The page you're looking for seems to have wandered into another story.</p>
      <a href="/" className="btn-primary">Back to Home</a>
    </div>
  );
}

function AppRoutes() {
  return (
    <Layout>
      <ScrollToTop />
      <AnnouncementBar />
      <Navbar />
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/books" element={<AllBooksPage />} />
          <Route path="/books/:id" element={<BookDetailsPage />} />
          <Route path="/cart" element={<CartPage />} />
          <Route path="/wishlist" element={<WishlistPage />} />
          <Route path="/about" element={<AboutPage />} />
          <Route path="/contact" element={<ContactPage />} />
          <Route path="/privacy" element={<InfoPage type="privacy" />} />
          <Route path="/terms" element={<InfoPage type="terms" />} />
          <Route path="/shipping" element={<InfoPage type="shipping" />} />
          <Route path="*" element={<NotFoundPage />} />
        </Routes>
      </main>
      <Footer />
    </Layout>
  );
}

function App() {
  return (
    <StoreProvider>
      <BrowserRouter>
        <AppRoutes />
      </BrowserRouter>
    </StoreProvider>
  );
}

export default App;

export type Language = 'urdu' | 'english';

export type Book = {
  id: string;
  title: string;
  titleUrdu?: string;
  author: string;
  language: Language;
  genre: string;
  category: string;
  price: number;
  originalPrice?: number;
  coverPalette: [string, string];
  coverAccent: string;
  coverIcon: 'book' | 'moon' | 'star' | 'sun' | 'rose' | 'feather' | 'leaf' | 'wave' | 'flame' | 'key' | 'crown' | 'heart' | 'water';
  description: string;
  isNew?: boolean;
  arrivalDate?: string;
  dateAdded: string;
  pages?: number;
  publisher?: string;
};

export type CollectionCard = {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  filterGenre?: string;
  filterLanguage?: Language;
  filterCategory?: string;
  filterNew?: boolean;
  icon: 'book-open' | 'globe' | 'heart' | 'search' | 'sparkles' | 'mountain' | 'star' | 'sunrise';
};

export type CartItem = {
  bookId: string;
  quantity: number;
};

export type CheckoutForm = {
  fullName: string;
  phone: string;
  email: string;
  city: string;
  address: string;
  notes: string;
};

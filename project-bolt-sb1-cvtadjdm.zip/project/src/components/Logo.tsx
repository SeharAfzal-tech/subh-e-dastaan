type LogoProps = {
  variant?: 'full' | 'mark';
  className?: string;
};

export function Logo({ variant = 'full', className = '' }: LogoProps) {
  if (variant === 'mark') {
    return (
      <svg viewBox="0 0 64 64" className={className} fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Subh-e-Dastaan logo">
        <circle cx="32" cy="32" r="31" fill="#FBF8F3" stroke="#C9A24A" strokeWidth="1.5" />
        <path d="M32 16C27 19 22 20 16 19v26c6 1 11 0 16-3 5 3 10 4 16 3V19c-6 1-11 0-16-3z" fill="#933F39" />
        <path d="M32 16C27 19 22 20 16 19v26c6 1 11 0 16-3V16z" fill="#6B2B26" />
        <line x1="32" y1="18" x2="32" y2="42" stroke="#F5EFE4" strokeWidth="1.2" opacity="0.4" />
        <circle cx="43" cy="22" r="7" fill="#DCBE73" />
        <path d="M43 15a7 7 0 0 1 0 14" fill="#C9A24A" />
        <g opacity="0.5">
          <path d="M20 44c1-3 4-5 7-5" stroke="#B08632" strokeWidth="0.8" fill="none" stroke-linecap="round" />
          <path d="M37 39c3 0 6 2 7 5" stroke="#B08632" strokeWidth="0.8" fill="none" stroke-linecap="round" />
        </g>
      </svg>
    );
  }

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      <svg viewBox="0 0 64 64" className="h-12 w-12 flex-shrink-0" fill="none" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Subh-e-Dastaan logo">
        <circle cx="32" cy="32" r="31" fill="#FBF8F3" stroke="#C9A24A" strokeWidth="1.5" />
        <path d="M32 16C27 19 22 20 16 19v26c6 1 11 0 16-3 5 3 10 4 16 3V19c-6 1-11 0-16-3z" fill="#933F39" />
        <path d="M32 16C27 19 22 20 16 19v26c6 1 11 0 16-3V16z" fill="#6B2B26" />
        <line x1="32" y1="18" x2="32" y2="42" stroke="#F5EFE4" strokeWidth="1.2" opacity="0.4" />
        <circle cx="43" cy="22" r="7" fill="#DCBE73" />
        <path d="M43 15a7 7 0 0 1 0 14" fill="#C9A24A" />
        <g opacity="0.5">
          <path d="M20 44c1-3 4-5 7-5" stroke="#B08632" strokeWidth="0.8" fill="none" stroke-linecap="round" />
          <path d="M37 39c3 0 6 2 7 5" stroke="#B08632" strokeWidth="0.8" fill="none" stroke-linecap="round" />
        </g>
      </svg>
      <div className="leading-tight">
        <p className="font-serif text-xl text-chocolate-600 tracking-wide">Subh-e-Dastaan</p>
        <p className="font-sans text-[10px] uppercase tracking-[0.18em] text-gold-600">Every Dawn Brings a New Story</p>
      </div>
    </div>
  );
}

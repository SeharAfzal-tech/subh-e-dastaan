import type { Book } from '@/types';

type BookCoverProps = {
  book: Book;
  className?: string;
};

function CoverIcon({ icon, color, size = 44 }: { icon: Book['coverIcon']; color: string; size?: number }) {
  const s = size;
  const stroke = color;
  const sw = 1.5;
  switch (icon) {
    case 'moon':
      return (
        <path
          d={`M${s * 0.5} ${s * 0.15}a${s * 0.3} ${s * 0.3} 0 1 0 0 ${s * 0.6}A${s * 0.3} ${s * 0.3} 0 0 1 ${s * 0.5} ${s * 0.15}z`}
          fill={color}
          opacity="0.9"
        />
      );
    case 'star':
      return (
        <path
          d={`M${s / 2} ${s * 0.1}L${s * 0.61} ${s * 0.38}L${s * 0.9} ${s * 0.4}L${s * 0.68} ${s * 0.58}L${s * 0.75} ${s * 0.87}L${s / 2} ${s * 0.72}L${s * 0.25} ${s * 0.87}L${s * 0.32} ${s * 0.58}L${s * 0.1} ${s * 0.4}L${s * 0.39} ${s * 0.38}z`}
          fill={color}
          opacity="0.9"
        />
      );
    case 'sun':
      return (
        <g stroke={stroke} strokeWidth={sw} fill="none">
          <circle cx={s / 2} cy={s / 2} r={s * 0.18} fill={color} opacity="0.9" />
          {Array.from({ length: 8 }).map((_, i) => {
            const a = (i * Math.PI) / 4;
            return (
              <line
                key={i}
                x1={s / 2 + Math.cos(a) * s * 0.24}
                y1={s / 2 + Math.sin(a) * s * 0.24}
                x2={s / 2 + Math.cos(a) * s * 0.38}
                y2={s / 2 + Math.sin(a) * s * 0.38}
              />
            );
          })}
        </g>
      );
    case 'rose':
      return (
        <g stroke={stroke} strokeWidth={sw} fill="none" opacity="0.9">
          <circle cx={s / 2} cy={s * 0.38} r={s * 0.1} fill={color} opacity="0.7" />
          <circle cx={s * 0.4} cy={s * 0.45} r={s * 0.07} fill={color} opacity="0.5" />
          <circle cx={s * 0.6} cy={s * 0.45} r={s * 0.07} fill={color} opacity="0.5" />
          <circle cx={s * 0.42} cy={s * 0.32} r={s * 0.06} fill={color} opacity="0.5" />
          <circle cx={s * 0.58} cy={s * 0.32} r={s * 0.06} fill={color} opacity="0.5" />
          <line x1={s / 2} y1={s * 0.48} x2={s / 2} y2={s * 0.85} />
          <path d={`M${s / 2} ${s * 0.65}Q${s * 0.3} ${s * 0.6} ${s * 0.25} ${s * 0.7}`} />
          <path d={`M${s / 2} ${s * 0.75}Q${s * 0.7} ${s * 0.7} ${s * 0.75} ${s * 0.8}`} />
        </g>
      );
    case 'feather':
      return (
        <g stroke={stroke} strokeWidth={sw} fill="none" opacity="0.9">
          <path d={`M${s * 0.35} ${s * 0.85}L${s * 0.7} ${s * 0.2}`} stroke={color} />
          <path d={`M${s * 0.55} ${s * 0.3}Q${s * 0.75} ${s * 0.32} ${s * 0.68} ${s * 0.5}z`} fill={color} opacity="0.6" />
          <path d={`M${s * 0.5} ${s * 0.4}Q${s * 0.72} ${s * 0.42} ${s * 0.63} ${s * 0.6}z`} fill={color} opacity="0.5" />
          <path d={`M${s * 0.45} ${s * 0.5}Q${s * 0.68} ${s * 0.52} ${s * 0.58} ${s * 0.7}z`} fill={color} opacity="0.4" />
        </g>
      );
    case 'leaf':
      return (
        <g stroke={stroke} strokeWidth={sw} fill="none" opacity="0.9">
          <path d={`M${s / 2} ${s * 0.85}Q${s * 0.85} ${s * 0.5} ${s / 2} ${s * 0.12}`} fill={color} opacity="0.6" />
          <line x1={s / 2} y1={s * 0.85} x2={s / 2} y2={s * 0.12} />
          <path d={`M${s / 2} ${s * 0.3}L${s * 0.65} ${s * 0.22}`} />
          <path d={`M${s / 2} ${s * 0.3}L${s * 0.35} ${s * 0.22}`} />
          <path d={`M${s / 2} ${s * 0.5}L${s * 0.68} ${s * 0.4}`} />
          <path d={`M${s / 2} ${s * 0.5}L${s * 0.32} ${s * 0.4}`} />
          <path d={`M${s / 2} ${s * 0.7}L${s * 0.65} ${s * 0.6}`} />
          <path d={`M${s / 2} ${s * 0.7}L${s * 0.35} ${s * 0.6}`} />
        </g>
      );
    case 'wave':
    case 'water':
      return (
        <g stroke={stroke} strokeWidth={sw} fill="none" opacity="0.9">
          <path d={`M${s * 0.1} ${s * 0.35}Q${s * 0.3} ${s * 0.2} ${s / 2} ${s * 0.35}T${s * 0.9} ${s * 0.35}`} />
          <path d={`M${s * 0.1} ${s * 0.5}Q${s * 0.3} ${s * 0.35} ${s / 2} ${s * 0.5}T${s * 0.9} ${s * 0.5}`} fill={color} opacity="0.4" />
          <path d={`M${s * 0.1} ${s * 0.65}Q${s * 0.3} ${s * 0.5} ${s / 2} ${s * 0.65}T${s * 0.9} ${s * 0.65}`} />
          <path d={`M${s * 0.1} ${s * 0.8}Q${s * 0.3} ${s * 0.65} ${s / 2} ${s * 0.8}T${s * 0.9} ${s * 0.8}`} fill={color} opacity="0.5" />
        </g>
      );
    case 'flame':
      return (
        <g stroke={stroke} strokeWidth={sw} fill="none" opacity="0.9">
          <path
            d={`M${s / 2} ${s * 0.1}Q${s * 0.7} ${s * 0.3} ${s * 0.65} ${s * 0.55}Q${s * 0.55} ${s * 0.45} ${s * 0.55} ${s * 0.55}Q${s * 0.5} ${s * 0.5} ${s / 2} ${s * 0.6}Q${s * 0.45} ${s * 0.5} ${s * 0.45} ${s * 0.55}Q${s * 0.45} ${s * 0.45} ${s * 0.35} ${s * 0.55}Q${s * 0.3} ${s * 0.3} ${s / 2} ${s * 0.1}z`}
            fill={color}
            opacity="0.7"
          />
        </g>
      );
    case 'key':
      return (
        <g stroke={stroke} strokeWidth={sw} fill="none" opacity="0.9">
          <circle cx={s * 0.38} cy={s * 0.35} r={s * 0.13} />
          <circle cx={s * 0.38} cy={s * 0.35} r={s * 0.05} fill={color} opacity="0.6" />
          <line x1={s * 0.48} y1={s * 0.43} x2={s * 0.8} y2={s * 0.75} />
          <line x1={s * 0.68} y1={s * 0.63} x2={s * 0.78} y2={s * 0.53} />
          <line x1={s * 0.6} y1={s * 0.55} x2={s * 0.7} y2={s * 0.45} />
        </g>
      );
    case 'crown':
      return (
        <g stroke={stroke} strokeWidth={sw} fill="none" opacity="0.9">
          <path
            d={`M${s * 0.15} ${s * 0.7}L${s * 0.2} ${s * 0.3}L${s * 0.35} ${s * 0.55}L${s / 2} ${s * 0.2}L${s * 0.65} ${s * 0.55}L${s * 0.8} ${s * 0.3}L${s * 0.85} ${s * 0.7}z`}
            fill={color}
            opacity="0.7"
          />
          <line x1={s * 0.15} y1={s * 0.78} x2={s * 0.85} y2={s * 0.78} />
        </g>
      );
    case 'heart':
      return (
        <path
          d={`M${s / 2} ${s * 0.8}C${s * 0.2} ${s * 0.55} ${s * 0.2} ${s * 0.25} ${s * 0.4} ${s * 0.25}C${s * 0.48} ${s * 0.25} ${s / 2} ${s * 0.32} ${s / 2} ${s * 0.4}C${s / 2} ${s * 0.32} ${s * 0.52} ${s * 0.25} ${s * 0.6} ${s * 0.25}C${s * 0.8} ${s * 0.25} ${s * 0.8} ${s * 0.55} ${s / 2} ${s * 0.8}z`}
          fill={color}
          opacity="0.85"
        />
      );
    case 'book':
    default:
      return (
        <g stroke={stroke} strokeWidth={sw} fill="none" opacity="0.9">
          <path d={`M${s * 0.25} ${s * 0.2}L${s * 0.25} ${s * 0.8}L${s * 0.75} ${s * 0.8}L${s * 0.75} ${s * 0.2}z`} fill={color} opacity="0.3" />
          <line x1={s / 2} y1={s * 0.2} x2={s / 2} y2={s * 0.8} />
          <path d={`M${s * 0.32} ${s * 0.35}L${s * 0.45} ${s * 0.35}`} />
          <path d={`M${s * 0.55} ${s * 0.35}L${s * 0.68} ${s * 0.35}`} />
          <path d={`M${s * 0.32} ${s * 0.5}L${s * 0.45} ${s * 0.5}`} />
          <path d={`M${s * 0.55} ${s * 0.5}L${s * 0.68} ${s * 0.5}`} />
          <path d={`M${s * 0.32} ${s * 0.65}L${s * 0.45} ${s * 0.65}`} />
          <path d={`M${s * 0.55} ${s * 0.65}L${s * 0.68} ${s * 0.65}`} />
        </g>
      );
  }
}

export function BookCover({ book, className = '' }: BookCoverProps) {
  const [c1, c2] = book.coverPalette;
  const accent = book.coverAccent;
  const gid = `cover-grad-${book.id}`;

  return (
    <div
      className={`relative overflow-hidden rounded-book bg-gradient-to-br ${className}`}
      style={{
        aspectRatio: '2 / 3',
        background: `linear-gradient(160deg, ${c1} 0%, ${c2} 100%)`,
      }}
    >
      <svg viewBox="0 0 100 150" className="absolute inset-0 h-full w-full" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
        <defs>
          <linearGradient id={gid} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor={c1} />
            <stop offset="100%" stopColor={c2} />
          </linearGradient>
        </defs>
        <rect width="100" height="150" fill={`url(#${gid})`} />
        {/* Spine line */}
        <line x1="8" y1="12" x2="8" y2="138" stroke={accent} strokeWidth="0.6" opacity="0.3" />
        {/* Top border */}
        <rect x="10" y="10" width="80" height="130" stroke={accent} strokeWidth="0.8" fill="none" opacity="0.35" rx="1" />
        {/* Icon */}
        <g transform="translate(28, 45)">
          <CoverIcon icon={book.coverIcon} color={accent} size={44} />
        </g>
        {/* Title */}
        <text
          x="50"
          y="108"
          textAnchor="middle"
          fontFamily="Fraunces, Georgia, serif"
          fontSize={book.title.length > 25 ? '5' : book.title.length > 15 ? '6' : '7'}
          fill="#F5EFE4"
          fontWeight="600"
        >
          {book.title.length > 28 ? book.title.slice(0, 27) + '…' : book.title}
        </text>
        {/* Author */}
        <text
          x="50"
          y="120"
          textAnchor="middle"
          fontFamily="Inter, sans-serif"
          fontSize="4"
          fill={accent}
          opacity="0.85"
        >
          {book.author}
        </text>
        {/* Bottom ornament */}
        <line x1="35" y1="128" x2="65" y2="128" stroke={accent} strokeWidth="0.5" opacity="0.4" />
        <circle cx="50" cy="128" r="1" fill={accent} opacity="0.6" />
      </svg>
      {/* Glossy highlight */}
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-tr from-transparent via-white/0 to-white/10" />
    </div>
  );
}

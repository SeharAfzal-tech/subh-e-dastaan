import { CheckCircle2 } from 'lucide-react';
import { useStore } from '@/store/StoreContext';

export function Toast() {
  const { toast } = useStore();
  if (!toast) return null;
  return (
    <div className="fixed bottom-6 right-6 z-[100] animate-fade-up">
      <div className="flex items-center gap-3 bg-chocolate-600 text-cream-50 px-5 py-3 rounded-2xl shadow-book-hover">
        <CheckCircle2 className="h-5 w-5 text-gold-300" />
        <p className="text-sm font-medium">{toast}</p>
      </div>
    </div>
  );
}

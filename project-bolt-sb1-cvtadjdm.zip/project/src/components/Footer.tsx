import { Link } from 'react-router-dom';
import { BookOpen, Heart, MapPin, Mail, Facebook, Instagram, Twitter } from 'lucide-react';
import { Logo } from '@/components/Logo';

const quickLinks = [
  { label: 'Home', path: '/' },
  { label: 'All Books', path: '/books' },
  { label: 'Bestsellers', path: '/books?category=Readers%27+Favourites' },
  { label: 'New Arrivals', path: '/books?new=true' },
  { label: 'About Us', path: '/about' },
  { label: 'Contact', path: '/contact' },
];

const categoryLinks = [
  { label: 'Urdu Novels', path: '/books?lang=urdu' },
  { label: 'English Novels', path: '/books?lang=english' },
  { label: 'Romance & Love Stories', path: '/books?genre=Romance' },
  { label: 'Mystery & Suspense', path: '/books?genre=Mystery' },
  { label: 'Spiritual & Inspirational', path: '/books?category=Spiritual+%26+Inspirational' },
  { label: 'Fantasy & Adventure', path: '/books?genre=Fantasy' },
];

export function Footer() {
  return (
    <footer className="bg-chocolate-600 text-cream-100 mt-20">
      <div className="container-px mx-auto max-w-7xl py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div>
            <div className="mb-4">
              <div className="flex items-center gap-3">
                <div className="h-12 w-12 rounded-full bg-cream-50 flex items-center justify-center">
                  <BookOpen className="h-7 w-7 text-burgundy-600" />
                </div>
                <div>
                  <p className="font-serif text-xl text-cream-50">Subh-e-Dastaan</p>
                  <p className="font-sans text-[10px] uppercase tracking-[0.18em] text-gold-300">Every Dawn Brings a New Story</p>
                </div>
              </div>
            </div>
            <p className="text-sm text-cream-200/80 leading-relaxed">
              A home for readers who believe every book holds a world of its own. Discover Urdu and English novels worth remembering.
            </p>
            <div className="flex gap-3 mt-6">
              <a href="#" className="p-2 rounded-full bg-chocolate-500 hover:bg-burgundy-600 transition-colors" aria-label="Facebook">
                <Facebook className="h-4 w-4" />
              </a>
              <a href="#" className="p-2 rounded-full bg-chocolate-500 hover:bg-burgundy-600 transition-colors" aria-label="Instagram">
                <Instagram className="h-4 w-4" />
              </a>
              <a href="#" className="p-2 rounded-full bg-chocolate-500 hover:bg-burgundy-600 transition-colors" aria-label="Twitter">
                <Twitter className="h-4 w-4" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-serif text-lg text-cream-50 mb-4">Quick Links</h3>
            <ul className="space-y-2">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link to={link.path} className="text-sm text-cream-200/80 hover:text-gold-300 transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-serif text-lg text-cream-50 mb-4">Book Categories</h3>
            <ul className="space-y-2">
              {categoryLinks.map((link) => (
                <li key={link.path}>
                  <Link to={link.path} className="text-sm text-cream-200/80 hover:text-gold-300 transition-colors">
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-serif text-lg text-cream-50 mb-4">Contact & Info</h3>
            <ul className="space-y-3 text-sm text-cream-200/80">
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 mt-0.5 text-gold-300 flex-shrink-0" />
                <span>Khanpur, Sindh, Pakistan</span>
              </li>
              <li className="flex items-start gap-2">
                <Mail className="h-4 w-4 mt-0.5 text-gold-300 flex-shrink-0" />
                <span>hello@subh-e-dastaan.com</span>
              </li>
            </ul>
            <div className="mt-6 space-y-2">
              <p className="text-sm text-cream-200/60">
                <Link to="/privacy" className="hover:text-gold-300 transition-colors">Privacy Policy</Link>
                <span className="mx-2">·</span>
                <Link to="/terms" className="hover:text-gold-300 transition-colors">Terms & Conditions</Link>
              </p>
              <p className="text-sm text-cream-200/60">
                <Link to="/shipping" className="hover:text-gold-300 transition-colors">Shipping & Returns</Link>
              </p>
            </div>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-chocolate-500/50 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm text-cream-200/70">
            &copy; {new Date().getFullYear()} Subh-e-Dastaan. All rights reserved.
          </p>
          <p className="text-sm text-cream-200/70 flex items-center gap-2">
            Made with <Heart className="h-3 w-3 text-burgundy-200 fill-burgundy-200" /> for book lovers in Khanpur, Sindh
          </p>
        </div>
      </div>
    </footer>
  );
}

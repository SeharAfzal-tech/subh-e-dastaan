import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { Search, Heart, ShoppingCart, Menu, X } from 'lucide-react';
import { Logo } from '@/components/Logo';
import { useStore } from '@/store/StoreContext';

const navLinks = [
  { label: 'Home', path: '/' },
  { label: 'All Books', path: '/books' },
  { label: 'Urdu Novels', path: '/books?lang=urdu' },
  { label: 'English Novels', path: '/books?lang=english' },
  { label: 'Bestsellers', path: '/books?category=Readers%27+Favourites' },
  { label: 'New Arrivals', path: '/books?new=true' },
  { label: 'About Us', path: '/about' },
  { label: 'Contact', path: '/contact' },
];

export function AnnouncementBar() {
  return (
    <div className="bg-burgundy-700 text-cream-50 text-center py-2 px-4 text-sm">
      <p className="font-sans tracking-wide">
        Welcome to Subh-e-Dastaan — Your Next Favourite Story Awaits!
      </p>
    </div>
  );
}

export function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');
  const navigate = useNavigate();
  const { cartCount, wishlist } = useStore();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) {
      navigate(`/books?q=${encodeURIComponent(query.trim())}`);
      setQuery('');
      setSearchOpen(false);
      setMobileOpen(false);
    }
  };

  return (
    <header className="sticky top-0 z-50 bg-cream-50/95 backdrop-blur-sm border-b border-cream-200">
      <nav className="container-px mx-auto max-w-7xl">
        <div className="flex items-center justify-between h-20 gap-4">
          <Link to="/" aria-label="Subh-e-Dastaan home">
            <Logo />
          </Link>

          <div className="hidden lg:flex items-center gap-1">
            {navLinks.map((link) => (
              <NavLink
                key={link.path}
                to={link.path}
                end={link.path === '/'}
                className={({ isActive }) =>
                  `px-3 py-2 text-sm font-medium rounded-full transition-colors ${
                    isActive ? 'text-burgundy-600' : 'text-chocolate-500 hover:text-burgundy-600 hover:bg-cream-100'
                  }`
                }
              >
                {link.label}
              </NavLink>
            ))}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setSearchOpen((v) => !v)}
              className="p-2 rounded-full text-chocolate-500 hover:bg-cream-100 transition-colors"
              aria-label="Search books"
            >
              <Search className="h-5 w-5" />
            </button>
            <Link
              to="/wishlist"
              className="relative p-2 rounded-full text-chocolate-500 hover:bg-cream-100 transition-colors"
              aria-label="View wishlist"
            >
              <Heart className="h-5 w-5" />
              {wishlist.length > 0 && (
                <span className="absolute top-0 right-0 bg-burgundy-600 text-cream-50 text-[10px] font-bold rounded-full h-4 w-4 flex items-center justify-center">
                  {wishlist.length}
                </span>
              )}
            </Link>
            <Link
              to="/cart"
              className="relative p-2 rounded-full text-chocolate-500 hover:bg-cream-100 transition-colors"
              aria-label="View cart"
            >
              <ShoppingCart className="h-5 w-5" />
              {cartCount > 0 && (
                <span className="absolute top-0 right-0 bg-burgundy-600 text-cream-50 text-[10px] font-bold rounded-full h-4 w-4 flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </Link>
            <button
              onClick={() => setMobileOpen((v) => !v)}
              className="lg:hidden p-2 rounded-full text-chocolate-500 hover:bg-cream-100 transition-colors"
              aria-label="Toggle menu"
            >
              {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {searchOpen && (
          <form onSubmit={handleSearch} className="pb-4 animate-slide-down">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-chocolate-300" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search by title, author, language, or category..."
                className="w-full rounded-full border border-cream-200 bg-white py-3 pl-12 pr-4 text-chocolate-500 focus:border-gold-400 focus:ring-2 focus:ring-gold-200/50 focus:outline-none"
                autoFocus
              />
            </div>
          </form>
        )}

        {mobileOpen && (
          <div className="lg:hidden pb-4 animate-slide-down">
            <div className="flex flex-col gap-1">
              {navLinks.map((link) => (
                <NavLink
                  key={link.path}
                  to={link.path}
                  end={link.path === '/'}
                  onClick={() => setMobileOpen(false)}
                  className={({ isActive }) =>
                    `px-4 py-3 text-sm font-medium rounded-xl transition-colors ${
                      isActive ? 'bg-burgundy-50 text-burgundy-600' : 'text-chocolate-500 hover:bg-cream-100'
                    }`
                  }
                >
                  {link.label}
                </NavLink>
              ))}
            </div>
          </div>
        )}
      </nav>
    </header>
  );
}

import { Link } from 'react-router-dom';
import { Heart, ShoppingBag, Eye } from 'lucide-react';
import type { Book } from '@/types';
import { formatPKR } from '@/data';
import { BookCover } from '@/components/BookCover';
import { useStore } from '@/store/StoreContext';

type BookCardProps = {
  book: Book;
};

export function BookCard({ book }: BookCardProps) {
  const { addToCart, toggleWishlist, isInWishlist } = useStore();
  const wished = isInWishlist(book.id);
  const discount = book.originalPrice ? Math.round(((book.originalPrice - book.price) / book.originalPrice) * 100) : 0;

  return (
    <div className="group card flex flex-col">
      <div className="relative p-3">
        <Link to={`/books/${book.id}`} aria-label={`View details for ${book.title}`}>
          <BookCover book={book} className="shadow-book transition-all duration-500 group-hover:shadow-book-hover group-hover:scale-[1.03]" />
        </Link>

        {/* Badges */}
        <div className="absolute top-5 left-5 flex flex-col gap-1.5">
          {book.isNew && (
            <span className="bg-gold-400 text-chocolate-600 text-[10px] font-bold uppercase tracking-wide px-2 py-1 rounded-full">
              New
            </span>
          )}
          {discount > 0 && (
            <span className="bg-burgundy-600 text-cream-50 text-[10px] font-bold px-2 py-1 rounded-full">
              -{discount}%
            </span>
          )}
        </div>

        {/* Wishlist */}
        <button
          onClick={() => toggleWishlist(book.id)}
          className="absolute top-5 right-5 p-2 rounded-full bg-white/90 shadow-soft hover:bg-white transition-all"
          aria-label={wished ? 'Remove from wishlist' : 'Add to wishlist'}
        >
          <Heart
            className={`h-4 w-4 transition-colors ${wished ? 'fill-burgundy-600 text-burgundy-600' : 'text-chocolate-400'}`}
          />
        </button>

        {/* Quick View */}
        <div className="absolute inset-x-3 bottom-3 flex gap-2 opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition-all duration-400">
          <Link
            to={`/books/${book.id}`}
            className="flex-1 flex items-center justify-center gap-1.5 bg-cream-50/95 backdrop-blur-sm text-chocolate-500 text-xs font-medium px-3 py-2 rounded-xl hover:bg-white transition-colors"
          >
            <Eye className="h-3.5 w-3.5" />
            Quick View
          </Link>
        </div>
      </div>

      <div className="flex flex-col flex-grow px-4 pb-4">
        <span className="text-[10px] uppercase tracking-wide text-gold-600 font-medium mb-1">{book.category}</span>
        <Link to={`/books/${book.id}`} className="hover:text-burgundy-600 transition-colors">
          <h3 className="font-serif text-base text-chocolate-600 leading-snug line-clamp-2 min-h-[2.5rem]">{book.title}</h3>
        </Link>
        <p className="text-xs text-chocolate-400 mb-3">by {book.author}</p>

        <div className="flex items-baseline gap-2 mb-3 mt-auto">
          <span className="font-serif text-lg text-burgundy-600 font-semibold">{formatPKR(book.price)}</span>
          {book.originalPrice && (
            <span className="text-xs text-chocolate-300 line-through">{formatPKR(book.originalPrice)}</span>
          )}
        </div>

        <button
          onClick={() => addToCart(book.id)}
          className="btn-primary w-full text-sm py-2.5"
        >
          <ShoppingBag className="h-4 w-4" />
          Add to Cart
        </button>
      </div>
    </div>
  );
}

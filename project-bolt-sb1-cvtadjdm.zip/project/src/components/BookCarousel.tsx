import { useRef } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import type { Book } from '@/types';
import { BookCard } from '@/components/BookCard';

type BookCarouselProps = {
  books: Book[];
  title: string;
  eyebrow?: string;
};

export function BookCarousel({ books, title, eyebrow }: BookCarouselProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: 'left' | 'right') => {
    if (!scrollRef.current) return;
    const amount = scrollRef.current.clientWidth * 0.8;
    scrollRef.current.scrollBy({ left: dir === 'left' ? -amount : amount, behavior: 'smooth' });
  };

  if (books.length === 0) return null;

  return (
    <section className="py-12">
      <div className="container-px mx-auto max-w-7xl">
        <div className="flex items-end justify-between mb-8 gap-4">
          <div>
            {eyebrow && <p className="eyebrow mb-2">{eyebrow}</p>}
            <h2 className="section-title">{title}</h2>
          </div>
          <div className="flex gap-2 flex-shrink-0">
            <button
              onClick={() => scroll('left')}
              className="p-2.5 rounded-full border border-cream-200 bg-white text-chocolate-500 hover:bg-cream-100 hover:border-gold-300 transition-colors"
              aria-label="Scroll left"
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              onClick={() => scroll('right')}
              className="p-2.5 rounded-full border border-cream-200 bg-white text-chocolate-500 hover:bg-cream-100 hover:border-gold-300 transition-colors"
              aria-label="Scroll right"
            >
              <ChevronRight className="h-5 w-5" />
            </button>
          </div>
        </div>

        <div
          ref={scrollRef}
          className="flex gap-5 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4"
        >
          {books.map((book) => (
            <div key={book.id} className="w-[240px] flex-shrink-0 sm:w-[260px]">
              <BookCard book={book} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

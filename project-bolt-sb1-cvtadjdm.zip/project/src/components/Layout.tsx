import { Toast } from '@/components/Toast';

type LayoutProps = {
  children: React.ReactNode;
};

export function Layout({ children }: LayoutProps) {
  return (
    <div className="min-h-screen flex flex-col bg-cream-50">
      {children}
      <Toast />
    </div>
  );
}
